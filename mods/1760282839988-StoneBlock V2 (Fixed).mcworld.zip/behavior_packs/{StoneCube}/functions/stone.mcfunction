execute @s ~ ~ ~ detect ~1 ~2 ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~2 ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~-1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~1 ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~1 ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~-1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~ ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~ ~ stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~-1 stone 0 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ kill @e[type=item,name="Mineral de hierro",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Mineral de Oro",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Diamante",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Lapislázuli",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Esmeralda",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="redstone",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="iron ore",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="gold ore",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="diamond",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="lapis lazuli",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="emerald",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="piedra rojiza",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="obsidian",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Obsidiana",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Bedrock",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Roca Madre",r=4]

execute @s ~ ~ ~ kill @e[type=item,name="Lecho de roca",r=4]

execute @s ~ ~ ~ detect ~1 ~2 ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~2 ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~-1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~1 ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~1 ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~-1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~ ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~ ~ stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~-1 stone 1 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~2 ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~2 ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~-1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~1 ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~1 ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~-1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~ ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~ ~ stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~-1 stone 3 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~2 ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~2 ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~2 ~-1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~1 ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~1 ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~1 ~-1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~1 ~ ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~-1 ~ ~ stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy

execute @s ~ ~ ~ detect ~ ~ ~-1 stone 5 fill ~-1 ~ ~-1 ~+1 ~+2 ~+1 air 0 destroy